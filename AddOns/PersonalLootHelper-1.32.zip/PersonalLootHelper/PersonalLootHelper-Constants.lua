PLH_LONG_ADDON_NAME = 'Personal Loot Helper'
PLH_SHORT_ADDON_NAME = 'PLH'
PLH_AUTHOR_NAME = 'Madone-Zul\'Jin'
